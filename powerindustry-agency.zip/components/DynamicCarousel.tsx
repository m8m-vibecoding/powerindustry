
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../App';
import { Language } from '../types';

const carouselImages = [
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500051/WhatsApp_Image_2026-02-03_at_22.18.16_11_s0a7x5.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500055/WhatsApp_Image_2026-02-03_at_22.18.16_xcspxj.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500052/WhatsApp_Image_2026-02-03_at_22.18.16_14_ejs09x.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500051/WhatsApp_Image_2026-02-03_at_22.18.16_9_d0zgli.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500050/WhatsApp_Image_2026-02-03_at_22.18.16_5_p5sqth.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500050/WhatsApp_Image_2026-02-03_at_22.18.15_20_uwyd5e.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500050/WhatsApp_Image_2026-02-03_at_22.18.15_6_jgkq17.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500050/WhatsApp_Image_2026-02-03_at_22.18.14_3_vii6k4.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500050/WhatsApp_Image_2026-02-03_at_22.18.15_21_kstfvh.jpg",
  "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770500050/WhatsApp_Image_2026-02-03_at_22.18.15_qv7udq.jpg",
];

const getAltText = (index: number, lang: Language) => {
  const n = index + 1;
  switch (lang) {
    case 'fr': return `Immersion Elite — moment d’entraînement (image ${n})`;
    case 'en': return `Elite Immersion — training moment (image ${n})`;
    case 'nl': return `Elite Immersion — trainingsmoment (afbeelding ${n})`;
    default: return `Elite Immersion (image ${n})`;
  }
};

const getAriaLabels = (lang: Language) => {
  switch (lang) {
    case 'fr': return { open: "Ouvrir l'image en grand", close: "Fermer", prev: "Image précédente", next: "Image suivante" };
    case 'nl': return { open: "Open in groot formaat", close: "Sluiten", prev: "Vorige afbeelding", next: "Volgende afbeelding" };
    default: return { open: "Open full size", close: "Close", prev: "Previous image", next: "Next image" };
  }
};

const TiltCard: React.FC<{ src: string; index: number; lang: Language; onClick: () => void }> = ({ src, index, lang, onClick }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const labels = getAriaLabels(lang);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    const tiltX = (y - centerY) / 20;
    const tiltY = (centerX - x) / 20;
    setTilt({ x: tiltX, y: tiltY });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  return (
    <div 
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative flex-shrink-0 w-[80vw] md:w-[600px] aspect-[16/9] mx-4 rounded-sm overflow-hidden group snap-center transition-transform duration-300 ease-out"
      style={{
        transform: `perspective(1000px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
      }}
    >
      <button 
        type="button"
        onClick={onClick}
        className="w-full h-full p-0 border-none bg-transparent block cursor-pointer"
        aria-label={`${labels.open} - ${index + 1}`}
      >
        <img 
          src={src} 
          alt={getAltText(index, lang)} 
          loading="lazy"
          decoding="async"
          className="w-full h-full object-cover filter brightness-75 group-hover:brightness-100 transition-all duration-500 scale-105 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A]/80 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />
        <div className="absolute bottom-6 left-6 opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0 duration-300">
          <span className="text-[10px] font-black uppercase tracking-[0.3em] text-[#FFA500]">0{index + 1} — Elite Series</span>
        </div>
      </button>
    </div>
  );
};

const Lightbox: React.FC<{ 
  images: string[]; 
  index: number; 
  onClose: () => void; 
  onPrev: () => void; 
  onNext: () => void;
  lang: Language;
}> = ({ images, index, onClose, onPrev, onNext, lang }) => {
  const labels = getAriaLabels(lang);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    closeRef.current?.focus();
    
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.style.overflow = 'auto';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onClose, onPrev, onNext]);

  return (
    <div 
      className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 md:p-12 select-none"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={labels.open}
    >
      <button 
        ref={closeRef}
        onClick={onClose}
        className="absolute top-6 right-6 md:top-10 md:right-10 z-[110] text-white/50 hover:text-white transition-colors p-2 rounded-full border border-white/10 hover:border-white/30 bg-white/5"
        aria-label={labels.close}
      >
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
      </button>

      <button 
        onClick={(e) => { e.stopPropagation(); onPrev(); }}
        className="absolute left-4 md:left-10 top-1/2 -translate-y-1/2 z-[110] text-white/50 hover:text-[#FFA500] transition-all p-4 rounded-full"
        aria-label={labels.prev}
      >
        <svg className="w-10 h-10 md:w-12 md:h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
      </button>

      <div 
        className="relative max-w-full max-h-full flex flex-col items-center gap-6"
        onClick={(e) => e.stopPropagation()}
      >
        <img 
          src={images[index]} 
          alt={getAltText(index, lang)}
          className="max-h-[80vh] md:max-h-[85vh] max-w-full object-contain shadow-2xl rounded-sm"
        />
        <div className="text-[#FFA500] font-black uppercase tracking-[0.4em] text-[10px] md:text-xs">
          {index + 1} / {images.length}
        </div>
      </div>

      <button 
        onClick={(e) => { e.stopPropagation(); onNext(); }}
        className="absolute right-4 md:right-10 top-1/2 -translate-y-1/2 z-[110] text-white/50 hover:text-[#FFA500] transition-all p-4 rounded-full"
        aria-label={labels.next}
      >
        <svg className="w-10 h-10 md:w-12 md:h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
      </button>
    </div>
  );
};

const DynamicCarousel: React.FC = () => {
  const { t, lang } = useLanguage();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    if (!scrollRef.current || isPaused || lightboxIndex !== null) return;

    const interval = setInterval(() => {
      if (scrollRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
        const newScroll = scrollLeft + 1;
        
        if (newScroll >= scrollWidth - clientWidth) {
          scrollRef.current.scrollLeft = 0;
        } else {
          scrollRef.current.scrollLeft = newScroll;
        }
      }
    }, 30);

    return () => clearInterval(interval);
  }, [isPaused, lightboxIndex]);

  const handleManualScroll = (direction: 'prev' | 'next') => {
    if (!scrollRef.current) return;
    const offset = direction === 'next' ? 400 : -400;
    scrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
  };

  const handlePrevImage = useCallback(() => {
    setLightboxIndex((prev) => (prev === null ? 0 : (prev - 1 + carouselImages.length) % carouselImages.length));
  }, []);

  const handleNextImage = useCallback(() => {
    setLightboxIndex((prev) => (prev === null ? 0 : (prev + 1) % carouselImages.length));
  }, []);

  return (
    <section className="py-24 bg-[#0A0A0A] overflow-hidden border-b border-gray-800/30">
      <div className="container mx-auto px-6 mb-12">
        <div className="max-w-xl">
          <h2 className="text-4xl md:text-5xl font-black mb-4 uppercase tracking-tighter text-gradient">
            {t.carousel.title}
          </h2>
          <p className="text-gray-500 uppercase tracking-widest text-xs italic">
            {t.carousel.subtitle}
          </p>
        </div>
      </div>

      <div className="relative group/carousel">
        <button 
          onClick={() => handleManualScroll('prev')}
          className="absolute left-6 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full border border-white/10 bg-[#0A0A0A]/50 backdrop-blur-md flex items-center justify-center text-white hover:text-[#FFA500] hover:border-[#FFA500] opacity-0 group-hover/carousel:opacity-100 transition-all focus:opacity-100 outline-none"
          aria-label="Previous slide"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <button 
          onClick={() => handleManualScroll('next')}
          className="absolute right-6 top-1/2 -translate-y-1/2 z-20 w-12 h-12 rounded-full border border-white/10 bg-[#0A0A0A]/50 backdrop-blur-md flex items-center justify-center text-white hover:text-[#FFA500] hover:border-[#FFA500] opacity-0 group-hover/carousel:opacity-100 transition-all focus:opacity-100 outline-none"
          aria-label="Next slide"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
        </button>

        <div 
          ref={scrollRef}
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
          className="flex overflow-x-auto no-scrollbar snap-x snap-mandatory py-4 px-4 cursor-grab active:cursor-grabbing"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {[...carouselImages, ...carouselImages].map((img, idx) => (
            <TiltCard 
              key={idx} 
              src={img} 
              index={idx % carouselImages.length} 
              lang={lang}
              onClick={() => setLightboxIndex(idx % carouselImages.length)}
            />
          ))}
        </div>
      </div>
      
      <div className="container mx-auto px-6 mt-12 flex justify-end">
        <div className="flex items-center space-x-2">
           <div className="w-12 h-[1px] bg-[#FFA500]" />
           <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Momentum Narrative</span>
        </div>
      </div>

      {lightboxIndex !== null && (
        <Lightbox 
          images={carouselImages}
          index={lightboxIndex}
          lang={lang}
          onClose={() => setLightboxIndex(null)}
          onPrev={handlePrevImage}
          onNext={handleNextImage}
        />
      )}
    </section>
  );
};

export default DynamicCarousel;

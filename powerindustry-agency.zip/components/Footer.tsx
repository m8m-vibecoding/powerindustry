
import React from 'react';
import { useLanguage } from '../App';

const Footer: React.FC = () => {
  const { t } = useLanguage();

  const socialLinks = {
    instagram: "https://www.instagram.com/powerindustry.agency?igsh=YmRsZ2QzdWV4ZzBp",
    tiktok: "https://www.tiktok.com/@powerindustry.agency?_t=ZN-907Di1Ol6N4&_r=1",
    x: "https://x.com/powerindustry_?s=21"
  };

  return (
    <footer className="bg-[#0A0A0A] border-t border-gray-800 pt-24 pb-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-1 md:col-span-2">
            <a href="#home" className="text-3xl font-black tracking-tighter mb-6 inline-block">
               <span className="text-white">POWER</span><span className="text-gradient">INDUSTRY</span>
            </a>
            <p className="text-gray-500 max-w-sm mb-8 leading-relaxed">
              L'agence qui structure et protège la carrière des athlètes d'élite sur les marchés européens.
            </p>
            <div className="flex space-x-6">
              <a 
                href={socialLinks.instagram} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-500 hover:text-[#FFA500] transition-colors font-bold text-xs uppercase tracking-widest"
              >
                Instagram
              </a>
              <a 
                href={socialLinks.tiktok} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-500 hover:text-[#FFA500] transition-colors font-bold text-xs uppercase tracking-widest"
              >
                TikTok
              </a>
              <a 
                href={socialLinks.x} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-500 hover:text-[#FFA500] transition-colors font-bold text-xs uppercase tracking-widest"
              >
                X (Twitter)
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-[10px] uppercase font-black tracking-[0.3em] text-[#FFA500] mb-6">Navigation</h4>
            <ul className="space-y-4">
              <li><a href="#home" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">{t.nav.home}</a></li>
              <li><a href="#services" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">{t.nav.services}</a></li>
              <li><a href="#players" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">{t.nav.players}</a></li>
              <li><a href="#contact" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">{t.nav.contact}</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[10px] uppercase font-black tracking-[0.3em] text-[#FFA500] mb-6">Légal</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">{t.footer.legal}</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">Privacy Policy</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-white transition-colors uppercase font-bold">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center pt-12 border-t border-gray-900 gap-6">
          <p className="text-[10px] uppercase font-bold text-gray-600 tracking-widest">
            {t.footer.rights}
          </p>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-[10px] uppercase font-black tracking-widest text-gray-600">All systems operational</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

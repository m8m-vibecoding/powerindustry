
import React from 'react';

const Partners: React.FC = () => {
  const partners = ["EFL", "Ligue 1", "Premier League", "FA", "KNVB", "FFF", "Adidas", "Nike", "Puma"];

  return (
    <div className="py-20 border-y border-gray-800 bg-[#0A0A0A] overflow-hidden">
      <div className="flex animate-marquee whitespace-nowrap">
        {[...partners, ...partners].map((p, idx) => (
          <div key={idx} className="flex items-center px-12">
            <span className="text-4xl md:text-6xl font-black text-transparent border-gray-800" style={{ WebkitTextStroke: '1px rgba(255,255,255,0.1)' }}>
              {p.toUpperCase()}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Partners;

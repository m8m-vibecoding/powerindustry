
import React from 'react';
import { useLanguage } from '../App';

const Hero: React.FC = () => {
  const { t, navigateToSection } = useLanguage();

  const handleCTA = (e: React.MouseEvent, id: string, tab?: 'player' | 'agent' | 'booking') => {
    e.preventDefault();
    navigateToSection(id, tab);
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-20 overflow-hidden scroll-mt-header">
      {/* Background with noise and overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://picsum.photos/id/1050/1920/1080" 
          alt="Stadium background" 
          className="w-full h-full object-cover opacity-30 scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/70 to-[#0A0A0A]/40" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-8xl font-black leading-[1] tracking-tight mb-8">
            {t.hero.headline} <br />
            <span className="text-gradient uppercase">{t.hero.headlineAccent}</span>
          </h1>
          
          <p className="text-lg md:text-2xl text-gray-300 max-w-2xl mb-12 leading-relaxed">
            {t.hero.subheadline}
          </p>

          <div className="flex flex-wrap gap-4 mb-16">
            <a 
              href="#contact" 
              onClick={(e) => handleCTA(e, 'contact', 'player')}
              className="px-8 py-4 bg-gradient-to-r from-[#FFA500] to-[#FFD700] text-[#0A0A0A] font-bold rounded-sm hover:scale-105 transition-all shadow-[0_0_20px_rgba(255,165,0,0.3)]"
            >
              {t.hero.ctaPlayer}
            </a>
            <a 
              href="#contact" 
              onClick={(e) => handleCTA(e, 'contact', 'agent')}
              className="px-8 py-4 bg-transparent border border-gray-700 text-white font-bold rounded-sm hover:border-[#FFA500] hover:text-[#FFA500] transition-all"
            >
              {t.hero.ctaAgent}
            </a>
            <a 
              href="#contact" 
              onClick={(e) => handleCTA(e, 'contact', 'booking')}
              className="w-full md:w-auto px-8 py-4 text-gray-400 hover:text-white underline underline-offset-8 transition-all"
            >
              {t.hero.ctaBooking}
            </a>
          </div>

          {/* Micro-trust badges */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl">
            {t.hero.trust.map((item, idx) => (
              <div key={idx} className="flex items-center space-x-3 p-4 glass-card rounded-lg">
                <div className="w-2 h-2 rounded-full bg-[#FFA500] animate-pulse" />
                <span className="text-xs font-bold uppercase tracking-widest text-gray-300">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Abstract Grid decoration */}
      <div className="absolute right-0 bottom-0 w-1/3 h-2/3 border-l border-t border-gray-800/30 -z-10" />
    </section>
  );
};

export default Hero;

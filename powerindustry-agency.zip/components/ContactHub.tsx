
import React, { useState } from 'react';
import { useLanguage, FormType } from '../App';

const ContactHub: React.FC = () => {
  const { t, activeContactTab, setActiveContactTab } = useLanguage();
  const [step, setStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setIsSubmitted(true);
  };

  const handleTabChange = (tab: FormType) => {
    setActiveContactTab(tab);
    setStep(1);
    setIsSubmitted(false);
  };

  const renderPlayerForm = () => {
    switch(step) {
      case 1: return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label htmlFor="p-fname" className="text-[10px] uppercase font-bold text-gray-500">Prénom</label>
              <input id="p-fname" required type="text" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
            </div>
            <div className="space-y-1">
              <label htmlFor="p-lname" className="text-[10px] uppercase font-bold text-gray-500">Nom</label>
              <input id="p-lname" required type="text" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
            </div>
          </div>
          <div className="space-y-1">
            <label htmlFor="p-email" className="text-[10px] uppercase font-bold text-gray-500">Email</label>
            <input id="p-email" required type="email" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
          </div>
          <button type="button" onClick={nextStep} className="w-full py-4 bg-white text-black font-black uppercase text-xs tracking-widest hover:bg-[#FFA500] transition-all">Continuer</button>
        </div>
      );
      case 2: return (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label htmlFor="p-age" className="text-[10px] uppercase font-bold text-gray-500">Âge</label>
              <input id="p-age" required type="number" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
            </div>
            <div className="space-y-1">
              <label htmlFor="p-pos" className="text-[10px] uppercase font-bold text-gray-500">Poste</label>
              <select id="p-pos" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none">
                <option>Gardien</option><option>Défenseur</option><option>Milieu</option><option>Attaquant</option>
              </select>
            </div>
          </div>
          <div className="space-y-1">
            <label htmlFor="p-club" className="text-[10px] uppercase font-bold text-gray-500">Club Actuel</label>
            <input id="p-club" required type="text" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
          </div>
          <div className="flex gap-4">
            <button type="button" onClick={prevStep} className="w-1/3 py-4 border border-gray-800 text-gray-400 font-bold uppercase text-[10px]">Retour</button>
            <button type="button" onClick={nextStep} className="w-2/3 py-4 bg-white text-black font-black uppercase text-xs tracking-widest">Continuer</button>
          </div>
        </div>
      );
      case 3: return (
        <div className="space-y-6">
          <div className="space-y-1">
            <label htmlFor="p-video" className="text-[10px] uppercase font-bold text-gray-500">Vidéo Highlights (Optionnel)</label>
            <input id="p-video" type="url" placeholder="Lien YouTube / Vimeo" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
          </div>
          <div className="space-y-1">
            <label htmlFor="p-goals" className="text-[10px] uppercase font-bold text-gray-500">Objectifs de carrière</label>
            <textarea id="p-goals" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none h-32" />
          </div>
          <div className="flex items-center space-x-3">
            <input required type="checkbox" className="w-5 h-5 accent-[#FFA500]" id="gdpr-p" />
            <label htmlFor="gdpr-p" className="text-[10px] text-gray-500 uppercase">J'accepte le traitement de mes données (RGPD)</label>
          </div>
          <div className="flex gap-4">
            <button type="button" onClick={prevStep} className="w-1/3 py-4 border border-gray-800 text-gray-400 font-bold uppercase text-[10px]">Retour</button>
            <button type="submit" className="w-2/3 py-4 bg-gradient-to-r from-[#FFA500] to-[#FFD700] text-[#0A0A0A] font-black uppercase text-xs tracking-widest shadow-[0_0_20px_rgba(255,165,0,0.3)]">Soumettre</button>
          </div>
        </div>
      );
      default: return null;
    }
  };

  const renderOtherForms = () => (
    <div className="space-y-6">
       <div className="space-y-1">
          <label htmlFor="o-name" className="text-[10px] uppercase font-bold text-gray-500">Nom complet</label>
          <input id="o-name" required type="text" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
       </div>
       <div className="space-y-1">
          <label htmlFor="o-email" className="text-[10px] uppercase font-bold text-gray-500">Email professionnel</label>
          <input id="o-email" required type="email" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none" />
       </div>
       <div className="space-y-1">
          <label htmlFor="o-msg" className="text-[10px] uppercase font-bold text-gray-500">Votre message</label>
          <textarea id="o-msg" className="w-full bg-[#121212] border border-gray-800 p-4 text-white focus:border-[#FFA500] outline-none h-32" />
       </div>
       <div className="flex items-center space-x-3">
          <input required type="checkbox" className="w-5 h-5 accent-[#FFA500]" id="gdpr-o" />
          <label htmlFor="gdpr-o" className="text-[10px] text-gray-500 uppercase">J'accepte le traitement de mes données (RGPD)</label>
       </div>
       <button type="submit" className="w-full py-4 bg-gradient-to-r from-[#FFA500] to-[#FFD700] text-[#0A0A0A] font-black uppercase text-xs tracking-widest">Soumettre</button>
    </div>
  );

  return (
    <section id="contact" className="py-32 bg-[#121212]/30 border-y border-gray-800 scroll-mt-header">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-black mb-4 uppercase tracking-tighter">CONTACT HUB</h2>
            <p className="text-gray-500 uppercase tracking-[0.2em] text-xs">Choose your path to excellence</p>
          </div>

          <div className="flex flex-col md:flex-row gap-8">
            {/* Tabs Sidebar */}
            <div className="md:w-1/3 flex md:flex-col gap-2 overflow-x-auto md:overflow-x-visible" role="tablist">
              {(['player', 'agent', 'booking'] as FormType[]).map((tab) => (
                <button
                  key={tab}
                  role="tab"
                  aria-selected={activeContactTab === tab}
                  aria-controls={`panel-${tab}`}
                  id={`tab-${tab}`}
                  onClick={() => handleTabChange(tab)}
                  className={`p-6 text-left border transition-all flex-1 md:flex-initial outline-none focus:ring-2 focus:ring-[#FFA500] ${activeContactTab === tab ? 'bg-white text-[#0A0A0A] border-white' : 'border-gray-800 text-gray-500 hover:border-gray-700'}`}
                >
                  <span className="block text-[10px] uppercase font-black tracking-widest opacity-50 mb-1">Path 0{tab === 'player' ? '1' : tab === 'agent' ? '2' : '3'}</span>
                  <span className="text-sm font-bold uppercase">{tab === 'player' ? 'Joueur' : tab === 'agent' ? 'Agent / Scout' : 'Booking'}</span>
                </button>
              ))}
            </div>

            {/* Form Area */}
            <div className="md:w-2/3 glass-card p-8 md:p-12 relative" role="tabpanel" id={`panel-${activeContactTab}`} aria-labelledby={`tab-${activeContactTab}`}>
              {isSubmitted ? (
                <div className="text-center py-20 flex flex-col items-center">
                  <div className="w-20 h-20 bg-[#FFA500] rounded-full flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(255,165,0,0.5)]">
                    <svg className="w-10 h-10 text-[#0A0A0A]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-black mb-4 uppercase tracking-tight">Merci !</h3>
                  <p className="text-gray-400">Votre demande a été reçue. Notre équipe vous contactera sous 48-72h.</p>
                  <button onClick={() => setIsSubmitted(false)} className="mt-8 text-xs underline underline-offset-8 text-gray-500 uppercase font-bold">Envoyer un autre message</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} id={`contact-${activeContactTab}`}>
                   <div className="mb-10 flex items-center justify-between">
                      <span className="text-xs font-black uppercase tracking-widest text-[#FFA500]">Étape {step} / {activeContactTab === 'player' ? '3' : '1'}</span>
                      <div className="flex space-x-2">
                        {(activeContactTab === 'player' ? [1, 2, 3] : [1]).map(s => (
                          <div key={s} className={`h-1 w-8 rounded-full ${s <= step ? 'bg-[#FFA500]' : 'bg-gray-800'}`} />
                        ))}
                      </div>
                   </div>
                   {activeContactTab === 'player' ? renderPlayerForm() : renderOtherForms()}
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactHub;


import React from 'react';
import { useLanguage } from '../App';

const Why: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section id="why" className="py-24 bg-[#0A0A0A] relative border-y border-gray-800/50 scroll-mt-header">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-black mb-16 text-center uppercase tracking-tighter">
          {t.why.title}
        </h2>

        {/* Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
          {t.why.pillars.map((pillar, idx) => (
            <div key={idx} className="p-8 glass-card rounded-lg relative overflow-hidden group">
              <div className="text-5xl font-black text-gray-800/30 absolute -top-4 -right-4 group-hover:text-[#FFA500]/10 transition-colors">
                0{idx + 1}
              </div>
              <h3 className="text-xl font-bold text-gradient mb-4 uppercase">{pillar.title}</h3>
              <p className="text-gray-400 leading-relaxed">{pillar.desc}</p>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div className="relative pt-10">
          <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-gray-800 hidden md:block" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10">
            {t.why.steps.map((step, idx) => (
              <div key={idx} className="flex flex-col items-center md:items-start text-center md:text-left">
                <div className="w-10 h-10 rounded-full bg-[#0A0A0A] border-2 border-[#FFA500] flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(255,165,0,0.4)]">
                  <span className="text-xs font-black text-white">{idx + 1}</span>
                </div>
                <h4 className="text-lg font-bold text-white mb-2 uppercase">{step.title}</h4>
                <p className="text-sm text-gray-500">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Why;

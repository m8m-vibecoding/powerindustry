
import React, { useState } from 'react';
import { useLanguage } from '../App';

const FAQ: React.FC = () => {
  const { t } = useLanguage();
  const [openIdx, setOpenIdx] = useState<string | null>(null);

  const toggle = (id: string) => setOpenIdx(openIdx === id ? null : id);

  return (
    <section className="py-32 bg-[#0A0A0A]">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-black mb-20 text-center uppercase">{t.faq.title}</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {/* Players FAQ */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-[0.3em] text-[#FFA500] mb-8">Section Joueurs</h3>
            <div className="space-y-4">
              {t.faq.players.map((item, idx) => (
                <div key={`p-${idx}`} className="border-b border-gray-800">
                  <button 
                    onClick={() => toggle(`p-${idx}`)}
                    className="w-full py-6 flex justify-between items-center text-left group"
                  >
                    <span className="text-sm font-bold uppercase tracking-tight group-hover:text-[#FFA500] transition-colors">{item.q}</span>
                    <span className={`transform transition-transform ${openIdx === `p-${idx}` ? 'rotate-45 text-[#FFA500]' : ''}`}>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                    </span>
                  </button>
                  <div className={`overflow-hidden transition-all duration-300 ${openIdx === `p-${idx}` ? 'max-h-40 pb-6' : 'max-h-0'}`}>
                    <p className="text-gray-500 text-sm leading-relaxed">{item.a}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Agents FAQ */}
          <div>
            <h3 className="text-xs font-black uppercase tracking-[0.3em] text-[#FFA500] mb-8">Section Agents / Recruteurs</h3>
            <div className="space-y-4">
              {t.faq.agents.map((item, idx) => (
                <div key={`a-${idx}`} className="border-b border-gray-800">
                  <button 
                    onClick={() => toggle(`a-${idx}`)}
                    className="w-full py-6 flex justify-between items-center text-left group"
                  >
                    <span className="text-sm font-bold uppercase tracking-tight group-hover:text-[#FFA500] transition-colors">{item.q}</span>
                    <span className={`transform transition-transform ${openIdx === `a-${idx}` ? 'rotate-45 text-[#FFA500]' : ''}`}>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                    </span>
                  </button>
                  <div className={`overflow-hidden transition-all duration-300 ${openIdx === `a-${idx}` ? 'max-h-40 pb-6' : 'max-h-0'}`}>
                    <p className="text-gray-500 text-sm leading-relaxed">{item.a}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;

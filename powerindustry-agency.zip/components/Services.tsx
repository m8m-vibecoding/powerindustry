
import React from 'react';
import { useLanguage } from '../App';

const Services: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section id="services" className="py-32 bg-[#0A0A0A] scroll-mt-header">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
          <h2 className="text-6xl md:text-8xl font-black uppercase tracking-tighter max-w-xl">
            {t.services.title}
          </h2>
          <p className="text-gray-400 max-w-md pb-4 italic">
            "Structure, protect and accelerate. Our services are tailored for the professional athlete."
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 border-l border-t border-gray-800">
          {t.services.list.map((service, idx) => (
            <div 
              key={idx} 
              className="p-10 border-r border-b border-gray-800 hover:bg-[#121212]/50 transition-all group"
            >
              <div className="mb-6 opacity-40 group-hover:opacity-100 transition-opacity">
                 <div className="w-12 h-1 bg-gradient-to-r from-[#FFA500] to-[#FFD700]" />
              </div>
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-tight text-white group-hover:text-gradient">
                {service.title}
              </h3>
              <p className="text-gray-400 mb-8 min-h-[60px]">
                {service.desc}
              </p>
              <div className="flex items-center space-x-2">
                <div className="w-1 h-1 rounded-full bg-[#FFA500]" />
                <span className="text-[10px] uppercase font-black tracking-widest text-[#FFA500]">
                  {service.proof}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;


import React, { useState, useEffect } from 'react';
import { useLanguage } from '../App';
import { Language } from '../types';

const Navbar: React.FC = () => {
  const { lang, setLang, t, navigateToSection } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      
      // Simple Scroll Spy logic
      const sections = ['home', 'services', 'players', 'about', 'contact'];
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 150 && rect.bottom >= 150) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: t.nav.home },
    { id: 'services', label: t.nav.services },
    { id: 'players', label: t.nav.players },
    { id: 'about', label: t.nav.about },
    { id: 'contact', label: t.nav.contact },
  ];

  const socialLinks = {
    instagram: "https://www.instagram.com/powerindustry.agency?igsh=YmRsZ2QzdWV4ZzBp",
    tiktok: "https://www.tiktok.com/@powerindustry.agency?_t=ZN-907Di1Ol6N4&_r=1",
    x: "https://x.com/powerindustry_?s=21"
  };

  const handleLinkClick = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    setIsOpen(false);
    navigateToSection(id);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'py-4 bg-[#0A0A0A]/80 backdrop-blur-md border-b border-gray-800' : 'py-6 bg-transparent'}`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        {/* Logo */}
        <a 
          href="#home" 
          onClick={(e) => handleLinkClick(e, 'home')}
          className="text-xl font-black tracking-tighter flex items-center group"
          aria-label="PowerIndustry Agency Home"
        >
          <span className="text-white group-hover:text-gradient transition-all">POWER</span>
          <span className="text-gradient">INDUSTRY</span>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-8" role="menubar">
          {navLinks.map((link) => (
            <a 
              key={link.id} 
              href={`#${link.id}`} 
              onClick={(e) => handleLinkClick(e, link.id)}
              className={`text-sm font-semibold transition-colors ${activeSection === link.id ? 'text-[#FFA500]' : 'text-gray-400 hover:text-white'}`}
              aria-current={activeSection === link.id ? 'page' : undefined}
              role="menuitem"
            >
              {link.label}
            </a>
          ))}
          
          {/* Lang Selector */}
          <div className="flex items-center space-x-2 border-l border-gray-800 pl-6 ml-6" role="group" aria-label="Language Selector">
            {(['fr', 'en', 'nl'] as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                aria-pressed={lang === l}
                className={`text-[10px] font-bold uppercase w-8 h-8 rounded-full border transition-all ${lang === l ? 'border-[#FFA500] text-[#FFA500]' : 'border-gray-800 text-gray-500 hover:text-white'}`}
              >
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile Toggle */}
        <button 
          onClick={() => setIsOpen(!isOpen)} 
          className="md:hidden text-white"
          aria-expanded={isOpen}
          aria-label="Toggle Navigation Menu"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            {isOpen ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" />}
          </svg>
        </button>
      </div>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 bg-[#0A0A0A] z-40 transition-transform duration-500 md:hidden ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col items-center justify-center h-full space-y-8 p-6">
          {navLinks.map((link) => (
            <a 
              key={link.id} 
              href={`#${link.id}`} 
              onClick={(e) => handleLinkClick(e, link.id)}
              className={`text-3xl font-bold transition-all ${activeSection === link.id ? 'text-gradient' : 'text-white hover:text-gradient'}`}
              aria-current={activeSection === link.id ? 'page' : undefined}
            >
              {link.label}
            </a>
          ))}
          
          {/* Social Links Mobile */}
          <div className="flex space-x-6 py-6 border-t border-gray-800 w-full justify-center">
            <a href={socialLinks.instagram} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#FFA500] font-bold text-xs uppercase tracking-widest">Instagram</a>
            <a href={socialLinks.tiktok} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#FFA500] font-bold text-xs uppercase tracking-widest">TikTok</a>
            <a href={socialLinks.x} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-[#FFA500] font-bold text-xs uppercase tracking-widest">X</a>
          </div>

          <div className="flex space-x-4 pt-4">
            {(['fr', 'en', 'nl'] as Language[]).map((l) => (
              <button
                key={l}
                onClick={() => { setLang(l); setIsOpen(false); }}
                className={`text-sm font-bold uppercase px-4 py-2 rounded-lg border transition-all ${lang === l ? 'border-[#FFA500] text-[#FFA500]' : 'border-gray-800 text-gray-500'}`}
              >
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

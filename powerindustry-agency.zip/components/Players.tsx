
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../App';
import { Language } from '../types';

interface Player {
  id: string;
  name: string;
  role: { [key in Language]: string };
  club: { [key in Language]: string };
  orgSubTag: { [key in Language]: string };
  nationality: { [key in Language]: string };
  details: { [key in Language]: string[] };
  img: string;
  alt: { [key in Language]: string };
}

const Players: React.FC = () => {
  const { t, lang, navigateToSection } = useLanguage();
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);

  // Close modal on ESC key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedPlayer(null);
    };
    if (selectedPlayer) {
      window.addEventListener('keydown', handleEsc);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }
    return () => {
      window.removeEventListener('keydown', handleEsc);
      document.body.style.overflow = 'auto';
    };
  }, [selectedPlayer]);

  const players: Player[] = [
    { 
      id: "schinear-mopila",
      name: "Schinéar Mopila", 
      role: {
        fr: "Défenseur central droit",
        en: "Right centre-back",
        nl: "Rechter centrale verdediger"
      },
      club: {
        fr: "@ LB Châteauroux",
        en: "@ LB Châteauroux",
        nl: "@ LB Châteauroux"
      },
      orgSubTag: {
        fr: "FFF • France",
        en: "FFF • France",
        nl: "FFF • Frankrijk"
      },
      nationality: {
        fr: "RD Congo",
        en: "DR Congo",
        nl: "DR Congo"
      },
      details: {
        fr: [
          "Nationalité : RD Congo",
          "Poste : Défenseur central droit",
          "Numéro : 28",
          "Taille / Poids : 1,87 m / 75 kg",
          "Sélection : RD Congo U20 (2 caps)",
          "Arrivée au club : 12/01/2025",
          "Statut : Sous représentation exclusive"
        ],
        en: [
          "Nationality: DR Congo",
          "Position: Right centre-back",
          "Shirt number: 28",
          "Height / Weight: 1.87 m / 75 kg",
          "International: DR Congo U20 (2 caps)",
          "Joined club: 12/01/2025",
          "Status: Under exclusive representation"
        ],
        nl: [
          "Nationaliteit: DR Congo",
          "Positie: Rechter centrale verdediger",
          "Rugnummer: 28",
          "Lengte / Gewicht: 1,87 m / 75 kg",
          "Interlands: DR Congo U20 (2)",
          "Bij de club sinds: 12/01/2025",
          "Status: Exclusieve vertegenwoordiging"
        ]
      },
      img: "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770498291/3_k7ijh6.png",
      alt: {
        fr: "Portrait de Schinéar Mopila, défenseur central à LB Châteauroux",
        en: "Portrait of Schinéar Mopila, centre-back at LB Châteauroux",
        nl: "Portret van Schinéar Mopila, centrale verdediger bij LB Châteauroux"
      }
    },
    { 
      id: "jalis-bouabdellah",
      name: "Jalis Bouabdellah", 
      role: {
        fr: "Milieu gauche",
        en: "Left midfielder",
        nl: "Linkermiddenvelder"
      },
      club: {
        fr: "@ Olympique Lyonnais U19",
        en: "@ Olympique Lyonnais U19",
        nl: "@ Olympique Lyonnais U19"
      },
      orgSubTag: {
        fr: "FFF • France",
        en: "FFF • France",
        nl: "FFF • Frankrijk"
      },
      nationality: {
        fr: "France / Algérie",
        en: "France / Algeria",
        nl: "Frankrijk / Algerije"
      },
      details: {
        fr: [
          "Nationalité : France / Algérie",
          "Poste : Milieu gauche",
          "Pied fort : Gauche",
          "Numéro : 48",
          "Club : Olympique Lyonnais U19",
          "Statut : Sous représentation exclusive"
        ],
        en: [
          "Nationality: France / Algeria",
          "Position: Left midfielder",
          "Strong foot: Left",
          "Shirt number: 48",
          "Club: Olympique Lyonnais U19",
          "Status: Under exclusive representation"
        ],
        nl: [
          "Nationaliteit: Frankrijk / Algerije",
          "Positie: Linkermiddenvelder",
          "Sterke voet: Links",
          "Rugnummer: 48",
          "Club: Olympique Lyonnais U19",
          "Status: Exclusieve vertegenwoordiging"
        ]
      },
      img: "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770498289/2_uyv4fe.png",
      alt: {
        fr: "Portrait de Jalis Bouabdellah, milieu gauche à l’Olympique Lyonnais U19",
        en: "Portrait of Jalis Bouabdellah, left midfielder at Olympique Lyonnais U19",
        nl: "Portret van Jalis Bouabdellah, linkermiddenvelder bij Olympique Lyonnais U19"
      }
    },
    { 
      id: "landry-kitenge",
      name: "Landry Kitenge", 
      role: {
        fr: "Ailier gauche",
        en: "Left winger",
        nl: "Linksbuiten"
      },
      club: {
        fr: "@ EA Guingamp B",
        en: "@ EA Guingamp B",
        nl: "@ EA Guingamp B"
      },
      orgSubTag: {
        fr: "FFF • France",
        en: "FFF • France",
        nl: "FFF • Frankrijk"
      },
      nationality: {
        fr: "France / RD Congo",
        en: "France / DR Congo",
        nl: "Frankrijk / DR Congo"
      },
      details: {
        fr: [
          "Nationalité : France / RD Congo",
          "Poste : Ailier gauche",
          "Lieu de naissance : Évry",
          "Taille : 1,75 m",
          "Numéro : À confirmer",
          "Statut : Sous représentation exclusive"
        ],
        en: [
          "Nationality: France / DR Congo",
          "Position: Left winger",
          "Place of birth: Évry",
          "Height: 1.75 m",
          "Shirt number: To confirm",
          "Status: Under exclusive representation"
        ],
        nl: [
          "Nationaliteit: Frankrijk / DR Congo",
          "Positie: Linksbuiten",
          "Geboorteplaats: Évry",
          "Lengte: 1,75 m",
          "Rugnummer: Te bevestigen",
          "Status: Exclusieve vertegenwoordiging"
        ]
      },
      img: "https://res.cloudinary.com/dj8vbaevh/image/upload/v1770498291/1_gtmair.png",
      alt: {
        fr: "Portrait de Landry Kitenge, ailier gauche à EA Guingamp B",
        en: "Portrait of Landry Kitenge, left winger at EA Guingamp B",
        nl: "Portret van Landry Kitenge, linksbuiten bij EA Guingamp B"
      }
    },
  ];

  return (
    <section id="players" className="py-32 bg-[#0A0A0A] scroll-mt-header">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-black mb-20 uppercase text-center">{t.players.title}</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {players.map((p, idx) => (
            <div 
              key={idx} 
              tabIndex={0}
              className="relative group cursor-pointer overflow-hidden rounded-sm outline-none focus:ring-2 focus:ring-[#FFA500]"
              onClick={() => setSelectedPlayer(p)}
              onKeyDown={(e) => e.key === 'Enter' && setSelectedPlayer(p)}
              role="button"
              aria-label={`View profile for ${p.name}`}
            >
              <img 
                src={p.img} 
                alt={p.alt[lang]} 
                loading="lazy"
                decoding="async"
                className="w-full aspect-[3/4] object-cover filter grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-0 left-0 p-8 w-full transform translate-y-4 group-hover:translate-y-0 transition-transform">
                <h3 className="text-2xl font-black text-white mb-1 uppercase tracking-tight">{p.name}</h3>
                <p className="text-[#FFA500] text-sm font-bold uppercase mb-4">{p.role[lang]}</p>
                <div className="flex justify-between items-center pt-4 border-t border-white/20 opacity-0 group-hover:opacity-100 transition-opacity">
                   <span className="text-[10px] text-gray-400 uppercase tracking-widest">{p.orgSubTag[lang]} • {p.nationality[lang]}</span>
                   <span className="text-xs text-white underline underline-offset-4">{t.players.cta}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {selectedPlayer && (
        <div 
          className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-[#0A0A0A]/95 backdrop-blur-xl"
          onClick={() => setSelectedPlayer(null)}
          role="dialog"
          aria-modal="true"
        >
          <div 
            className="glass-card w-full max-w-4xl rounded-sm overflow-hidden flex flex-col md:flex-row relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => setSelectedPlayer(null)}
              className="absolute top-6 right-6 text-white hover:text-[#FFA500] z-10 p-2"
              aria-label="Close profile modal"
            >
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
            
            <div className="md:w-1/2">
              <img 
                src={selectedPlayer.img} 
                className="w-full h-full object-cover" 
                alt={selectedPlayer.alt[lang]} 
              />
            </div>
            
            <div className="md:w-1/2 p-10 flex flex-col justify-center">
              <span className="text-[#FFA500] font-bold uppercase tracking-widest text-xs mb-4">Talent Profile</span>
              <h3 className="text-4xl font-black text-white mb-2 uppercase">{selectedPlayer.name}</h3>
              <div className="text-xl text-gray-400 mb-8 italic">
                <p>{selectedPlayer.role[lang]}</p>
                <p>{selectedPlayer.club[lang]}</p>
              </div>
              
              <div className="space-y-6 mb-12">
                <div>
                  <h4 className="text-xs font-black uppercase tracking-widest text-gray-500 mb-4">{t.players.modalKeyPoints}</h4>
                  <ul className="space-y-3">
                    {selectedPlayer.details[lang].map((detail, idx) => (
                      <li key={idx} className="flex items-center space-x-3">
                        <div className="w-1.5 h-1.5 bg-[#FFA500]" />
                        <span className="text-sm">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <a 
                href="#contact" 
                onClick={(e) => {
                  e.preventDefault();
                  setSelectedPlayer(null);
                  navigateToSection('contact', 'booking');
                }}
                className="w-full py-4 text-center bg-white text-[#0A0A0A] font-black uppercase text-sm tracking-widest hover:bg-[#FFA500] transition-colors"
              >
                Demander infos scouting
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Players;

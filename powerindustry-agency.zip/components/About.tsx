
import React from 'react';
import { useLanguage } from '../App';

const About: React.FC = () => {
  const { t } = useLanguage();

  return (
    <section id="about" className="py-32 bg-[#0A0A0A] scroll-mt-header">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-center gap-20">
          <div className="lg:w-1/2 relative">
             <div className="absolute -top-10 -left-10 w-40 h-40 border-l-2 border-t-2 border-[#FFA500] opacity-30" />
             <img 
               src="https://res.cloudinary.com/dj8vbaevh/image/upload/v1770498991/logo_powerindustry_xliiyi.png" 
               alt="PowerIndustry Vision" 
               className="rounded-sm shadow-2xl relative z-10 w-full object-cover"
             />
             <div className="absolute -bottom-6 -right-6 w-1/2 h-1/2 bg-gradient-to-br from-[#FFA500]/20 to-transparent -z-10" />
          </div>
          
          <div className="lg:w-1/2">
            <div className="mb-8">
              <h2 className="text-5xl font-black uppercase bg-[#FFA500] text-white px-6 py-2 inline-block leading-tight">
                {t.about.title}
              </h2>
            </div>
            <div className="space-y-6 text-lg text-gray-400 leading-relaxed italic border-l-4 border-gray-800 pl-8">
              <p>{t.about.content}</p>
            </div>
            
            <div className="mt-12 grid grid-cols-2 gap-8">
              <div>
                <span className="block text-3xl font-black text-white mb-1">EUROPE</span>
                <span className="text-xs uppercase tracking-widest text-[#FFA500]">Focus Marché</span>
              </div>
              <div>
                <span className="block text-3xl font-black text-white mb-1">PRO</span>
                <span className="text-xs uppercase tracking-widest text-[#FFA500]">Elite Standard</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

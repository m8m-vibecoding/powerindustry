
import React, { useState, createContext, useContext, useEffect, useCallback } from 'react';
import { Language } from './types';
import { content } from './i18n/content';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Why from './components/Why';
import Services from './components/Services';
import DynamicCarousel from './components/DynamicCarousel';
import Players from './components/Players';
import Partners from './components/Partners';
import About from './components/About';
import ContactHub from './components/ContactHub';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import BackToTop from './components/BackToTop';

export type FormType = 'player' | 'agent' | 'booking';

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: typeof content.en;
  activeContactTab: FormType;
  setActiveContactTab: (tab: FormType) => void;
  navigateToSection: (id: string, tab?: FormType) => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('pi_locale');
    if (saved === 'fr' || saved === 'en' || saved === 'nl') return saved;
    const browserLang = navigator.language.split('-')[0];
    if (browserLang === 'fr' || browserLang === 'en' || browserLang === 'nl') return browserLang as Language;
    return 'fr';
  });

  const [activeContactTab, setActiveContactTab] = useState<FormType>('player');

  useEffect(() => {
    localStorage.setItem('pi_locale', lang);
    document.documentElement.lang = lang;
  }, [lang]);

  const navigateToSection = useCallback((id: string, tab?: FormType) => {
    if (tab) {
      setActiveContactTab(tab);
    }
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      // Update hash without jumping
      window.history.pushState(null, '', `#${id}`);
      
      // Accessibility focus management
      if (tab || id === 'contact') {
        setTimeout(() => {
          const firstInput = document.querySelector(`#contact-${tab || activeContactTab} input`) as HTMLElement;
          firstInput?.focus();
        }, 800);
      }
    }
  }, [activeContactTab]);

  const value = {
    lang,
    setLang,
    t: content[lang],
    activeContactTab,
    setActiveContactTab,
    navigateToSection
  };

  return (
    <LanguageContext.Provider value={value}>
      <div className="relative min-h-screen bg-[#0A0A0A] overflow-x-hidden selection:bg-[#FFA500] selection:text-[#0A0A0A]">
        {/* Textured Void Overlay */}
        <div className="fixed inset-0 textured-void z-[1]" />
        
        <div className="relative z-10">
          <Navbar />
          <main>
            <Hero />
            <Why />
            <Services />
            <DynamicCarousel />
            <Players />
            <Partners />
            <About />
            <ContactHub />
            <FAQ />
          </main>
          <Footer />
          <BackToTop />
        </div>
      </div>
    </LanguageContext.Provider>
  );
};

export default App;

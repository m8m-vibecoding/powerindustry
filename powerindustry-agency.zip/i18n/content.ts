
import { ContentSchema, Language } from '../types';

export const content: Record<Language, ContentSchema> = {
  fr: {
    nav: { home: "Accueil", services: "Services", players: "Joueurs", about: "À propos", contact: "Contact" },
    hero: {
      headline: "STRATÉGIE & RÉSEAU POUR LE FOOTBALL DE",
      headlineAccent: "DEMAIN",
      subheadline: "Une agence premium qui structure, protège et accélère les carrières football via réseau, stratégie et représentation.",
      ctaPlayer: "Je suis joueur",
      ctaAgent: "Je suis agent / recruteur",
      ctaBooking: "Demande de booking",
      trust: ["Réseau International", "Stratégie de Carrière", "Protection Juridique"]
    },
    why: {
      title: "Pourquoi PowerIndustry ?",
      pillars: [
        { title: "Transparence", desc: "Une éthique de travail rigoureuse sans compromis sur l'intégrité." },
        { title: "Expertise", desc: "Des conseillers spécialisés dans chaque aspect du sport de haut niveau." },
        { title: "Accélération", desc: "Des opportunités concrètes grâce à un réseau mondial consolidé." }
      ],
      steps: [
        { title: "Découverte", desc: "Analyse approfondie du profil et des besoins." },
        { title: "Stratégie", desc: "Établissement d'un plan de carrière personnalisé." },
        { title: "Exécution", desc: "Négociation et déploiement sur le terrain." },
        { title: "Long Terme", desc: "Suivi constant pour une carrière durable." }
      ]
    },
    services: {
      title: "Nos Services",
      list: [
        { title: "Représentation", desc: "Gestion contractuelle et négociations professionnelles.", proof: "Sécurité juridique" },
        { title: "Stratégie", desc: "Orientation de carrière et choix des clubs.", proof: "Vision long-terme" },
        { title: "Scouting", desc: "Identification d'opportunités sur les marchés ciblés.", proof: "Réseau global" },
        { title: "Image", desc: "Accompagnement marque personnelle et visibilité.", proof: "Notoriété" },
        { title: "Performance", desc: "Coordination avec des experts physiques et mentaux.", proof: "Écosystème élite" },
        { title: "International", desc: "Passerelle vers les championnats UK, France, Irlande.", proof: "Mobilité" }
      ]
    },
    carousel: {
      title: "Immersion Elite",
      subtitle: "Dans les coulisses du haut niveau. Vision, rigueur, trajectoire."
    },
    players: {
      title: "Nos Talents",
      cta: "Voir le profil",
      modalBio: "Profil de joueur professionnel suivi par PowerIndustry.",
      modalKeyPoints: "Points clés"
    },
    about: {
      title: "Notre Vision",
      content: "Fondée sur la volonté de professionnaliser l'accompagnement des talents, PowerIndustry Agency se positionne comme un partenaire stratégique. Nous ne sommes pas de simples agents, nous sommes des architectes de carrière. Notre mission est d'éliminer le bruit ambiant pour permettre au joueur de se concentrer uniquement sur son football, tout en ouvrant les portes des marchés européens les plus compétitifs."
    },
    faq: {
      title: "Questions Fréquentes",
      players: [
        { q: "Comment rejoindre l'agence ?", a: "Remplissez le formulaire joueur. Notre équipe analyse chaque profil et revient vers vous sous 72h." },
        { q: "Quels sont vos marchés ciblés ?", a: "Nous sommes particulièrement actifs en France, au Royaume-Uni et en Irlande." }
      ],
      agents: [
        { q: "Proposez-vous des mandats ?", a: "Nous travaillons en collaboration avec des agents licenciés pour des missions spécifiques." },
        { q: "Comment devenir partenaire ?", a: "Utilisez le parcours Agent/Recruteur pour nous présenter votre réseau." }
      ]
    },
    footer: {
      social: "Suivez-nous",
      legal: "Mentions Légales",
      rights: "© 2024 PowerIndustry Agency. Tous droits réservés."
    }
  },
  en: {
    nav: { home: "Home", services: "Services", players: "Players", about: "About", contact: "Contact" },
    hero: {
      headline: "STRATEGY & NETWORK FOR THE FOOTBALL OF",
      headlineAccent: "TOMORROW",
      subheadline: "A premium agency structuring, protecting, and accelerating football careers through network, strategy, and representation.",
      ctaPlayer: "I am a player",
      ctaAgent: "I am an agent / scout",
      ctaBooking: "Booking request",
      trust: ["International Network", "Career Strategy", "Legal Protection"]
    },
    why: {
      title: "Why PowerIndustry?",
      pillars: [
        { title: "Transparency", desc: "A rigorous work ethic without compromise on integrity." },
        { title: "Expertise", desc: "Specialized advisors in every aspect of elite sport." },
        { title: "Acceleration", desc: "Concrete opportunities through a consolidated global network." }
      ],
      steps: [
        { title: "Discovery", desc: "In-depth profile and needs analysis." },
        { title: "Strategy", desc: "Establishment of a personalized career plan." },
        { title: "Execution", desc: "Negotiation and on-field deployment." },
        { title: "Long Term", desc: "Constant follow-up for a sustainable career." }
      ]
    },
    services: {
      title: "Our Services",
      list: [
        { title: "Representation", desc: "Contract management and professional negotiations.", proof: "Legal security" },
        { title: "Strategy", desc: "Career orientation and club selection.", proof: "Long-term vision" },
        { title: "Scouting", desc: "Identifying opportunities in targeted markets.", proof: "Global network" },
        { title: "Image", desc: "Personal brand support and visibility guidance.", proof: "Visibility" },
        { title: "Performance", desc: "Coordination with physical and mental experts.", proof: "Elite ecosystem" },
        { title: "International", desc: "Bridge to UK, France, Ireland championships.", proof: "Mobility" }
      ]
    },
    carousel: {
      title: "Elite Immersion",
      subtitle: "Behind elite performance. Vision, rigor, trajectory."
    },
    players: {
      title: "Our Talents",
      cta: "View Profile",
      modalBio: "Professional player profile managed by PowerIndustry.",
      modalKeyPoints: "Key points"
    },
    about: {
      title: "Our Vision",
      content: "Founded on the desire to professionalize talent support, PowerIndustry Agency positions itself as a strategic partner. We are not just agents; we are career architects. Our mission is to eliminate surrounding noise, allowing players to focus solely on their football, while opening doors to the most competitive European markets."
    },
    faq: {
      title: "Frequent Questions",
      players: [
        { q: "How to join the agency?", a: "Complete the player form. Our team reviews every profile and gets back to you within 72h." },
        { q: "What are your target markets?", a: "We are particularly active in France, the UK, and Ireland." }
      ],
      agents: [
        { q: "Do you offer mandates?", a: "We collaborate with licensed agents for specific missions." },
        { q: "How to become a partner?", a: "Use the Agent/Scout path to introduce your network." }
      ]
    },
    footer: {
      social: "Follow us",
      legal: "Legal Notices",
      rights: "© 2024 PowerIndustry Agency. All rights reserved."
    }
  },
  nl: {
    nav: { home: "Home", services: "Diensten", players: "Spelers", about: "Over ons", contact: "Contact" },
    hero: {
      headline: "STRATEGIE & NETWERK VOOR HET VOETBAL VAN",
      headlineAccent: "MORGEN",
      subheadline: "Een premium agentschap dat voetbalcarrières structureert, beschermt en versnelt via netwerk, strategie en vertegenwoordiging.",
      ctaPlayer: "Ik ben een speler",
      ctaAgent: "Ik ben een agent / recruiter",
      ctaBooking: "Booking aanvraag",
      trust: ["Internationaal Netwerk", "Carrièrestrategie", "Juridische Bescherming"]
    },
    why: {
      title: "Waarom PowerIndustry?",
      pillars: [
        { title: "Transparantie", desc: "Een rigoureuze werkethiek zonder compromissen op integriteit." },
        { title: "Expertise", desc: "Gespecialiseerde adviseurs in elk aspect van topsport." },
        { title: "Versnelling", desc: "Concrete kansen via een geconsolideerd wereldwijd netwerk." }
      ],
      steps: [
        { title: "Ontdekking", desc: "Grondige analyse van profiel en behoeften." },
        { title: "Strategie", desc: "Vaststelling van een gepersonaliseerd carrièreplan." },
        { title: "Uitvoering", desc: "Onderhandeling en implementatie op het veld." },
        { title: "Lange Termijn", desc: "Constante opvolging voor een duurzame carrière." }
      ]
    },
    services: {
      title: "Onze Diensten",
      list: [
        { title: "Vertegenwoordiging", desc: "Contractbeheer en professionele onderhandelingen.", proof: "Juridische veiligheid" },
        { title: "Strategie", desc: "Carrièreoriëntatie en clubkeuze.", proof: "Lange-termijn visie" },
        { title: "Scouting", desc: "Kansen identificeren in doelmarkten.", proof: "Wereldwijd netwerk" },
        { title: "Imago", desc: "Ondersteuning van persoonlijk merk en zichtbaarheid.", proof: "Bekendheid" },
        { title: "Prestatie", desc: "Coördinatie met fysieke en mentale experts.", proof: "Elite ecosysteem" },
        { title: "Internationaal", desc: "Brug naar kampioenschappen in UK, Frankrijk, Ierland.", proof: "Mobiliteit" }
      ]
    },
    carousel: {
      title: "Elite Onderdompeling",
      subtitle: "Achter topprestaties. Visie, discipline, traject."
    },
    players: {
      title: "Onze Talenten",
      cta: "Bekijk profiel",
      modalBio: "Professioneel spelersprofiel beheerd door PowerIndustry.",
      modalKeyPoints: "Belangrijkste punten"
    },
    about: {
      title: "Onze Visie",
      content: "Gebaseerd op de wens om talentondersteuning te professionaliseren, positioneert PowerIndustry Agency zich als een strategische partner. Wij zijn niet zomaar agenten; wij zijn carrière-architecten. Onze missie is om omgevingsgeluid te elimineren, zodat spelers zich uitsluitend op hun voetbal kunnen concentreren, terwijl we de deuren openen naar de meest competitieve Europese markten."
    },
    faq: {
      title: "Veelgestelde Vragen",
      players: [
        { q: "Hoe lid worden?", a: "Vul het spelersformulier in. Ons team analyseert elk profiel en reageert binnen 72 uur." },
        { q: "Wat zijn jullie doelmarkten?", a: "Wij zijn bijzonder actief in Frankrijk, het VK en Ierland." }
      ],
      agents: [
        { q: "Bieden jullie mandaten aan?", a: "We werken samen met gelicentieerde agenten voor specifieke missies." },
        { q: "Hoe partner worden?", a: "Gebruik het Agent/Scout-traject om uw netwerk voor te stellen." }
      ]
    },
    footer: {
      social: "Volg ons",
      legal: "Juridische Informatie",
      rights: "© 2024 PowerIndustry Agency. Alle rechten voorbehouden."
    }
  }
};

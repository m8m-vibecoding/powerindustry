
export type Language = 'fr' | 'en' | 'nl';

export interface PlayerLead {
  id: string;
  createdAt: string;
  language: Language;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  age: string;
  nationality: string;
  position: string;
  foot: string;
  club: string;
  level: string;
  contractStatus: string;
  availabilityDate: string;
  targetCountries: string[];
  highlightsUrl?: string;
  goalsText: string;
  consent: boolean;
}

export interface AgentLead {
  id: string;
  createdAt: string;
  language: Language;
  name: string;
  email: string;
  phone: string;
  organization?: string;
  role: string;
  baseCountry: string;
  markets: string[];
  specialty: string;
  networkText: string;
  motivationText: string;
  availability: string;
  consent: boolean;
}

export interface BookingLead {
  id: string;
  createdAt: string;
  language: Language;
  profileType: string;
  topic: string;
  message: string;
  slots: string[];
  timezone: string;
  consent: boolean;
}

export interface ContentSchema {
  nav: {
    home: string;
    services: string;
    players: string;
    about: string;
    contact: string;
  };
  hero: {
    headline: string;
    headlineAccent: string;
    subheadline: string;
    ctaPlayer: string;
    ctaAgent: string;
    ctaBooking: string;
    trust: string[];
  };
  why: {
    title: string;
    pillars: Array<{ title: string; desc: string }>;
    steps: Array<{ title: string; desc: string }>;
  };
  services: {
    title: string;
    list: Array<{ title: string; desc: string; proof: string }>;
  };
  carousel: {
    title: string;
    subtitle: string;
  };
  players: {
    title: string;
    cta: string;
    modalBio: string;
    modalKeyPoints: string;
  };
  about: {
    title: string;
    content: string;
  };
  faq: {
    title: string;
    players: Array<{ q: string; a: string }>;
    agents: Array<{ q: string; a: string }>;
  };
  footer: {
    social: string;
    legal: string;
    rights: string;
  };
}
